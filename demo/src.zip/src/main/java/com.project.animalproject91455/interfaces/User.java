package com.project.animalproject91455.interfaces;public class User {
}
