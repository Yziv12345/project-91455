package animalproject91455;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AnimalProject91455ApplicationTests {

	@Test
	void contextLoads() {
	}

}
